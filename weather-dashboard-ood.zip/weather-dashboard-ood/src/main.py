# main.py
if __name__ == "__main__":
    app = WeatherDashboardApp()
    app.run()